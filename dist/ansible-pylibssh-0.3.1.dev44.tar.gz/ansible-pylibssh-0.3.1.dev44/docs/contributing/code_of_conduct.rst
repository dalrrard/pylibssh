.. include:: ../../.github/CODE_OF_CONDUCT.rst
